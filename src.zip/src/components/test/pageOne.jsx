import React from "react";

function PageOne() {
    return (
        <>
            <h1>Hello world!</h1>
        </>
    );
}

export default PageOne;
