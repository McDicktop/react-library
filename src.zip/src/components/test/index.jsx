import PageOne from "./pageOne";
import PageTwo from "./pageTwo";

export { PageOne, PageTwo };
